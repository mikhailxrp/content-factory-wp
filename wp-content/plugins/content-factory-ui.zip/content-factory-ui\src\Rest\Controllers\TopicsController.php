<?php

namespace ContentFactoryUI\Rest\Controllers;

use ContentFactoryUI\N8n\Client;
use ContentFactoryUI\N8n\Endpoints;
use ContentFactoryUI\Cache\TransientCache;
use ContentFactoryUI\Logger\Logger;

/**
 * REST контроллер для тем
 */
class TopicsController {
  /**
   * Получить список тем по run_id
   */
  public static function list($request) {
    $run_id = $request->get_param('run_id');
    $meaning_id = $request->get_param('meaning_id');

    if (empty($run_id)) {
      return rest_ensure_response([
        'success' => false,
        'message' => __('Не указан run_id', 'content-factory-ui')
      ]);
    }

    $client = new Client();
    $endpoint = Endpoints::get('list_topics');

    $params = [
      'run_id' => $run_id
    ];

    if (!empty($meaning_id)) {
      $params['meaning_id'] = $meaning_id;
    }
    
    $topics = $client->get($endpoint, $params);

    if (is_wp_error($topics)) {
      return rest_ensure_response([
        'success' => false,
        'message' => $topics->get_error_message()
      ]);
    }

    // Сбрасываем кэш при получении новых данных
    TransientCache::delete('topics_list');

    return rest_ensure_response([
      'success' => true,
      'data' => $topics
    ]);
  }

  /**
   * Генерация тем по run_id
   */
  public static function generate($request) {
    $run_id = $request->get_param('run_id');
    $meaning_id = $request->get_param('meaning_id');

    if (empty($run_id)) {
      return rest_ensure_response([
        'success' => false,
        'message' => __('Не указан run_id', 'content-factory-ui')
      ]);
    }

    $client = new Client();
    $client->set_timeout(120);
    
    $endpoint = Endpoints::get('generate_topics');

    $query = [
      'run_id' => $run_id
    ];

    if (!empty($meaning_id)) {
      $query['meaning_id'] = $meaning_id;
    }

    $response = $client->post($endpoint . '?' . http_build_query($query));

    if (is_wp_error($response)) {
      return rest_ensure_response([
        'success' => false,
        'message' => $response->get_error_message()
      ]);
    }

    // Сбрасываем кэш после генерации
    TransientCache::delete('topics_list');

    return rest_ensure_response([
      'success' => true,
      'message' => __('Темы сгенерированы', 'content-factory-ui'),
      'data' => $response
    ]);
  }

  /**
   * Обновление тем по run_id (и опционально по meaning_id)
   */
  public static function update($request) {
    $run_id = $request->get_param('run_id');
    $meaning_id = $request->get_param('meaning_id');

    if (empty($run_id)) {
      return rest_ensure_response([
        'success' => false,
        'message' => __('Не указан run_id', 'content-factory-ui')
      ]);
    }

    $client = new Client();
    $client->set_timeout(120);
    
    $endpoint = Endpoints::get('update_topics');

    // Собираем query-параметры по аналогии с generate()
    $query = [
      'run_id' => $run_id,
    ];

    if (!empty($meaning_id)) {
      $query['meaning_id'] = $meaning_id;
    }

    $response = $client->post($endpoint . '?' . http_build_query($query), [
      'mode' => 'regenerate'
    ]);

    if (is_wp_error($response)) {
      return rest_ensure_response([
        'success' => false,
        'message' => $response->get_error_message()
      ]);
    }

    // Сбрасываем кэш после обновления
    TransientCache::delete('topics_list');

    return rest_ensure_response([
      'success' => true,
      'message' => __('Темы обновлены', 'content-factory-ui'),
      'data' => $response
    ]);
  }

  /**
   * Получить конкретную тему
   */
  public static function get($request) {
    $id = $request->get_param('id');

    if (empty($id)) {
      return rest_ensure_response([
        'success' => false,
        'message' => __('Не указан ID темы', 'content-factory-ui')
      ]);
    }
    
    $client = new Client();
    $endpoint = Endpoints::get('get_topic');
    
    $topic = $client->get($endpoint . '?id=' . urlencode($id));

    if (is_wp_error($topic)) {
      return rest_ensure_response([
        'success' => false,
        'message' => $topic->get_error_message()
      ]);
    }

    return rest_ensure_response([
      'success' => true,
      'data' => $topic
    ]);
  }

  /**
   * Обновить структуру темы
   */
  public static function update_outline($request) {
    $id = $request->get_param('id');
    $data = $request->get_json_params();

    $client = new Client();
    $endpoint = Endpoints::get('update_outline') ?? '/webhook/topics/' . $id . '/outline';

    $response = $client->post($endpoint, [
      'outline' => $data['outline']
    ]);

    if (is_wp_error($response)) {
      return rest_ensure_response([
        'success' => false,
        'message' => $response->get_error_message()
      ]);
    }

    return rest_ensure_response([
      'success' => true,
      'message' => __('Структура обновлена', 'content-factory-ui'),
      'data' => $response
    ]);
  }

  /**
   * Обновить одну тему по run_id и meaning_id
   */
  public static function update_one($request) {
    $run_id = $request->get_param('run_id');
    $meaning_id = $request->get_param('meaning_id');
    $data = $request->get_json_params();

    if (empty($run_id) || empty($meaning_id)) {
      return rest_ensure_response([
        'success' => false,
        'message' => __('Не указан run_id или meaning_id', 'content-factory-ui')
      ]);
    }

    $topic = isset($data['topic']) && is_array($data['topic']) ? $data['topic'] : [];

    if (empty($topic['topic_candidate_id'])) {
      return rest_ensure_response([
        'success' => false,
        'message' => __('Не указан topic_candidate_id темы', 'content-factory-ui')
      ]);
    }

    $client = new Client();
    $endpoint = Endpoints::get('update_topic') ?? '/webhook/topics/update-one';

    $payload = [
      'run_id' => $run_id,
      'meaning_id' => $meaning_id,
      'topic' => $topic
    ];

    $response = $client->post($endpoint, $payload);

    if (is_wp_error($response)) {
      return rest_ensure_response([
        'success' => false,
        'message' => $response->get_error_message()
      ]);
    }

    // Сбрасываем кэш после обновления
    TransientCache::delete('topics_list');

    return rest_ensure_response([
      'success' => true,
      'message' => __('Тема обновлена', 'content-factory-ui'),
      'data' => $response
    ]);
  }

  /**
   * Генерация статьи из темы
   */
  public static function generate_article($request) {
    $id = $request->get_param('id');

    if (empty($id)) {
      return rest_ensure_response([
        'success' => false,
        'message' => __('Не указан ID темы', 'content-factory-ui')
      ]);
    }

    $client = new Client();
    // n8n возвращает ответ сразу, генерация идет в фоне
    
    $endpoint = Endpoints::get('generate_article');
    
    Logger::debug("Генерация статьи для темы ID: $id");
    
    // Отправляем id как query-параметр
    $response = $client->post($endpoint . '?id=' . urlencode($id));

    if (is_wp_error($response)) {
      Logger::error('Ошибка генерации: ' . $response->get_error_message());
      return rest_ensure_response([
        'success' => false,
        'message' => $response->get_error_message()
      ]);
    }

    Logger::debug('Статья успешно сгенерирована');
    
    // Сбрасываем кэш статей
    TransientCache::delete('articles_list');

    return rest_ensure_response([
      'success' => true,
      'message' => __('Генерация статьи запущена', 'content-factory-ui'),
      'data' => $response
    ]);
  }

  /**
   * Проверка статуса генерации статьи
   */
  public static function check_article_status($request) {
    $id = $request->get_param('id');

    if (empty($id)) {
      return rest_ensure_response([
        'success' => false,
        'message' => __('Не указан ID темы', 'content-factory-ui')
      ]);
    }

    $client = new Client();
    $endpoint = Endpoints::get('check_article_status');
    
    Logger::debug("Проверка статуса генерации статьи для темы ID: $id");
    
    // Отправляем id как query-параметр
    $response = $client->get($endpoint . '?id=' . urlencode($id));

    if (is_wp_error($response)) {
      Logger::error('Ошибка проверки статуса: ' . $response->get_error_message());
      return rest_ensure_response([
        'success' => false,
        'message' => $response->get_error_message()
      ]);
    }

    Logger::debug('Статус получен', $response);

    return rest_ensure_response([
      'success' => true,
      'data' => $response
    ]);
  }

  /**
   * Проверка прав доступа
   */
  public static function check_permission() {
    return current_user_can('edit_posts');
  }
}
